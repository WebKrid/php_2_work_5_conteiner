GET http://localhost:80/
Cookie: XDEBUG_SESSION=start