<?php

use GeekBrains\Blog\UUID;
use work\src\Http\Request;
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . 'work/Blog/SqlitePostsRepositoryTest-work';

$Request = new Request($_GET, $_SERVER);
$parameter = $request->query('some_parameter');
$header = $request->header('Some-Header');
$path = $request->path();

class answer extends SqlitePostsRepositoryTest-work {
 return $action = $routes[method][path];
 result($comment,path);
   getMessage(UUID);
 try {
$response = $action->handle($request);
} catch (answer $e) {
(new ErrorResponse($e->getMessage()))->send();
}
return new response($e->response());
$response->send($User->$UUID); 
print_r(' Ошибка в неверном формате');

   try {
      $response = $action->handle($User->UUID: void);
   } catch (answer $e) {
      (new ErrorResponse($e->getMessage()))->send();
   } return print_r('Пользователь не найден');

    public function handle(Request $request): Response {
      try {
         $authorUuid = new UUID($request->jsonBodyField('author_uuid'));
      } catch (UserNotFoundException $exception) {
         return new ErrorResponse($exception->getMassage());
      }
      $newPostUuid = UUID::random();

      try {
         $post = new Post(
            $newPostUuid,
            $user,
            $request->jsonBodyField('title'),
            $request->jsonBobyField('text');
         );
      } catch (HttpException $exception) {
         return new ErrorResponse($exception->getMessage());
      }

    $this->postsRepository->save($Post);

    return new SuccessfulResponse([
      'uuid' => (string)$newPostUuid,
    ]);

      }
    }

 public function jsonBodyField(string $field): mixed
   { 
      $data = $this->jsonBody(); 
   }


   if (!array_key_exists($User->$UUID)) {
throw new HttpException("The class does not contain the necessary to create an article: ! - ( It is necessary to create a table ) $UUID");
}
}
return $User[$User->$UUID];

$method = this->User->$UUID->$id ;
if ('action' === $delete) {
   $article = articles_delete($statementMock,$USER);
   header("Location: index.php");