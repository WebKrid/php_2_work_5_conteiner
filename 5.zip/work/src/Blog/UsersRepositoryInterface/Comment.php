<?php

namespace GeekBrains\LevelTwo\Blog;


class Comment
{
    private int $id;
    private User $user;
    private Post $post;
    private string $text;

    /**
     * Summary of __construct
     * @param int $id
     * @param User $user
     * @param Post $post
     * @param string $text
     */
    public function __construct(int $id, User $user, Post $post, string $text)
    {
        $this->id = $id;
        $this->user = $user;
        $this->post = $post;
        $this->text = $text;
    }
    public function __toString()
    {
        return $this->user . " пишет комментарий " . $this->text;
    }
    /**
     * Summary of getId
     * @return int
     */
    public function getId():int
    {
        return $this->id;
    }
    /**
     * Summary of setId
     * @param mixed $id
     * @return void
     */
    public function setId($id):void
    {
        $this->id = $id;
    }
    /**
     * Summary of getText
     * @return string
     */
    public function getText():string
    {
        return $this->text;
    }
    /**
     * Summary of setText
     * @param mixed $text
     * @return void
     */
    public function setText($text):void
    {
        $this->text = $text;
    }
     /**
      * Summary of getUser
      * @return User
      */
     public function getUser():User
     {
          return $this->user;
     }
     /**
      * Summary of setUser
      * @param mixed $user
      * @return void
      */
     public function setUser($user):void
     {
          $this->user = $user;
     }
    /**
     * Summary of getPost
     * @return Post
     */
    public function getPost():Post
    {
        return $this->post;
    }
    /**
     * Summary of setPost
     * @param mixed $post
     * @return void
     */
    public function setPost($post):void
    {
        $this->post = $post;
    }
}