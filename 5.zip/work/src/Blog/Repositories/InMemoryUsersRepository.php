<?php
namespace GeekBrains\LevelTwo\Blog\Repositories;

use GeekBrains\LevelTwo\Blog\User;
use GeekBrains\LevelTwo\Blog\Repositories\Comment;
use GeekBrains\LevelTwo\Blog\Repositories\Post;
use GeekBrains\LevelTwo\Blog\SqlitePostsRepositoryTest-work;
use GeekBrains\LevelTwo\Blog\Exceptions\UserNotFoundException;
use GeekBrains\LevelTwo\Blog\Exceptions\AppException;
use GeekBrains\LevelTwo\Blog\Exceptions\UUD;
use GeekBrains\LevelTwo\Blog\Exceptions\InMemoryUsersRepository;
class InMemoryUsersRepository
{
    /**
     * Summary of users
     * @var array
     */
    private array $users = [];

    /**
     * Summary of save
     * @param User $user
     * @return void
     */
    public function save(User $user): void
    {
        $this->users[] = $user;
    }

    /**
     * Summary of get
     * @param int $id
     * @throws UserNotFoundException
     * @return User
     */
    public function get(int $id): User
    {
        foreach ($this->users as $user) {
            if ($user->getId() === $id) {
                return $user;
            }
        }
        throw new UserNotFoundException("User not found: $id");
    }
}
